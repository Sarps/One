<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php $__env->startSection('include'); ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(URL::to('images/android.png')); ?>" rel="icon" >
    <!-- Fonts -->
    <link href="<?php echo e(URL::to('css/bootstrap.min.css')); ?>" rel="stylesheet" >
    <link href="<?php echo e(URL::to('css/w3file.css')); ?>" rel="stylesheet" >
    <script src="<?php echo e(URL::to('js/jqueryfile.js')); ?>"></script>
    <script src="<?php echo e(URL::to('js/bootstrap.min.js')); ?>"></script>
    <?php echo $__env->yieldSection(); ?>
<style type="text/css">
    #wrapper {
        width:50%;
        height: 50%;
        margin-left:auto;
        margin-right:auto;
        margin-top:50px;
    }

    a:hover{
        text-decoration: none;
    }


</style>
</head>
<body>

    <div id="wrapper">
         <table class="table w3-striped table-responsive">
    <thead class="w3-center">
        <caption> <?php echo $__env->yieldContent('total'); ?></caption>
      <tr>
        <th>Names</th>
        <th>Gender</th>
        <th>Index No.</th>
      </tr>
    </thead>
    <tbody>
      <?php echo $__env->yieldContent('content'); ?>
    </tbody>
  </table>

        <a href="<?php echo e(route('welcome')); ?>"><button class="button btn-block btn-primary w3-round">Go Back</button></a>
    
</div>
   
    </div>
</body>
</html>