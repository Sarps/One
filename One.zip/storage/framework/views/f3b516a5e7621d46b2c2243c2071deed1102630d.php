<?php $__env->startSection('total'); ?>

 <h4>Parallel Students Registered <span style="float:right"> Total: <?php echo e($total_para); ?> <span><h4> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div>
	<?php if(Session::has('add')): ?>
		<div class="alert alert-success">
			<?php echo e(Session::get('add')); ?>

		</div>
	<?php endif; ?>
</div>

 <?php $__currentLoopData = $parallel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $para): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($para->name); ?></td>
        <td><?php echo e($para->gender); ?></td>
        <td><?php echo e($para->indexno); ?></td>
      </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>